package examples;

public class View {
    public void display(String data) {
        System.out.println("Data: " + data);
    }
}