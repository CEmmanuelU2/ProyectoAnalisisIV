package examples;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Model {
    private String data;
}