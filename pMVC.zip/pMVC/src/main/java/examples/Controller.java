package examples;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class Controller {
    private final Model model;
    private final View view;

    public void setData(String data) {
        model.setData(data);
    }

    public void updateView() {
        view.display(model.getData());
    }
}